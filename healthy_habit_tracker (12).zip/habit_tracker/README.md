# 🌿 Healthy Habit Tracker
GreenFuture Hack · Project #33 · Health & Wellbeing

A Streamlit app to track **reading, exercise and hydration** over a week – with strict input validation,
local JSON persistence, search, executive summaries, Matplotlib charts, multi-format export and bulk CSV import.

## Quick start – terminal version (no Streamlit needed)
```bash
python3 cli.py
```
Menu-driven, colour ANSI output. Choose **8** to load sample data. Only the standard library is required
(`pip3 install matplotlib` if you want PNG charts).

## Quick start – Streamlit version
```bash
./run.sh            # macOS/Linux   (run.bat on Windows)
# or manually:
pip install -r requirements.txt
streamlit run app.py
```
Then open **Import & Export → Data tools → Load sample dataset** to fill the app with 40 demo entries.

## Brief → feature map
| Requirement | Where |
|---|---|
| Interface (menu-driven) | Streamlit sidebar navigation, 5 pages (`app.py`) |
| Defensive input validation | `core.validate_entry` – type, range, date, habit, note checks; amount is a free-text box so bad input is caught live |
| Core business logic | `core.build_summary`, `habit_summary`, `current_streak` |
| Local persistence (JSON/CSV) | `core.HabitStore` – atomic writes, corrupt-file backup & reset, schema checks |
| Search & filter | **Records** page – keyword, habit, date range, pagination |
| Executive summary | **Dashboard** + **Insights** – totals, averages, goal days, streaks, trend, status |
| Matplotlib charts | `charts.py` – trend, consistency heatmap, goal bars, distribution, combined PNG |
| Multi-format export (stretch) | Markdown, text audit log, CSV, PNG |
| Threshold warnings (stretch) | Anomalous values, missed days, overdue habits, 3-day goal misses |
| Bulk import (stretch) | CSV upload with row-by-row error log (downloadable) |
| Sample data | `data/sample_habits.csv` / `.json` – 40 entries incl. boundary & anomaly cases |

## Habit rules
| Habit | Unit | Valid range | Daily goal | Flagged above |
|---|---|---|---|---|
| Reading | min | 0–600 | 30 | 300 |
| Exercise | min | 0–300 | 30 | 180 |
| Hydration | ml | 0–8000 | 2000 | 5000 |

Status per habit (days meeting goal in the 7-day window): ≥80% On track · 50–79% Needs attention · <50% Off track.
Edit `HABITS` in `habit_tracker/core.py` to change goals or add habits.

## Suggested demo script
1. Dashboard with sample data loaded → point out alerts and charts.
2. **Log a habit** → enter `abc`, `-5`, `9999` → see each rejected; then enter `45`.
3. **Records** → search "jog".
4. **Import** → upload `data/legacy_import_with_errors.csv` → show the error log.
5. Stop and rerun the app → data persists. **Export** a Markdown report / PNG.

## Tests
```bash
python -m unittest discover -s tests -v     # 19 tests, standard library only
```
