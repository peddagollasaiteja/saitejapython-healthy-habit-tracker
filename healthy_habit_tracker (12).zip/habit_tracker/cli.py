"""Healthy Habit Tracker – interactive terminal interface.

Run with:  python3 cli.py
Needs only the standard library (matplotlib is optional, for charts).
"""
from __future__ import annotations

import json
import os
import sys
import webbrowser
from datetime import date, datetime, timedelta
from pathlib import Path

from habit_tracker.core import (
    HABITS, MAX_NOTE_LEN, HabitStore, build_summary, import_log_csv, markdown_report,
    parse_csv_import, records_csv, shift_records_to_end, text_report, threshold_warnings,
    today, validate_entry,
)

ROOT = Path(__file__).resolve().parent
DATA_FILE = ROOT / "data" / "habits.json"
SAMPLE_JSON = ROOT / "data" / "sample_habits.json"
EXPORT_DIR = ROOT / "exports"

# --------------------------------------------------------------------------- #
# ANSI helpers
# --------------------------------------------------------------------------- #
USE_COLOR = sys.stdout.isatty() and not os.environ.get("NO_COLOR")


def c(text, code):
    return f"\033[{code}m{text}\033[0m" if USE_COLOR else str(text)


bold = lambda t: c(t, "1")
dim = lambda t: c(t, "2")
green = lambda t: c(t, "32")
red = lambda t: c(t, "31")
yellow = lambda t: c(t, "33")
cyan = lambda t: c(t, "36")
magenta = lambda t: c(t, "35")
TONE = {"good": green, "warn": yellow, "bad": red}
LEVEL = {"critical": red, "warning": yellow, "info": cyan}


def fmt(v) -> str:
    return f"{v:,.1f}".rstrip("0").rstrip(".") if isinstance(v, float) else f"{v:,}"


def banner():
    lines = [
        "╔══════════════════════════════════════════════════════╗",
        "║        🌿  H E A L T H Y   H A B I T   T R A C K E R  ║",
        "║        Reading · Exercise · Hydration  —  weekly view ║",
        "╚══════════════════════════════════════════════════════╝",
    ]
    print()
    for ln in lines:
        print(cyan(ln))


def heading(text):
    print("\n" + bold(magenta(f"▌ {text}")))
    print(dim("─" * 60))


def progress_bar(pct, width=20):
    filled = round(min(max(pct, 0), 100) / 100 * width)
    return "█" * filled + "░" * (width - filled)


# --------------------------------------------------------------------------- #
# Safe input wrappers (loop until valid; never crash on blank/odd input)
# --------------------------------------------------------------------------- #
def ask(prompt: str, default: str | None = None) -> str:
    suffix = f" [{default}]" if default else ""
    raw = input(f"{prompt}{suffix}: ").strip()
    return raw or (default or "")


def ask_until_valid(prompt, check, default=None):
    """``check(text) -> list[str]`` of errors. Loops until there are none."""
    while True:
        text = ask(prompt, default)
        errs = check(text)
        if not errs:
            return text
        for e in errs:
            print(red(f"  ✖ {e}"))
        print(dim("  Please try again (Ctrl+C to cancel)."))


def confirm(prompt) -> bool:
    return ask(f"{prompt} (y/N)").lower() in ("y", "yes")


def table(headers, rows, widths):
    line = "  ".join(f"{h:<{w}}" for h, w in zip(headers, widths))
    print(bold(line))
    print(dim("  ".join("─" * w for w in widths)))
    for r in rows:
        print("  ".join(f"{str(v)[:w]:<{w}}" for v, w in zip(r, widths)))


# --------------------------------------------------------------------------- #
# Actions
# --------------------------------------------------------------------------- #
def log_habit(store: HabitStore):
    heading("Log a habit")
    d = ask_until_valid("Date YYYY-MM-DD (Enter = today)",
                        lambda t: validate_entry(t, "Reading", 0)[1], today().isoformat())
    for i, (h, s) in enumerate(HABITS.items(), 1):
        print(f"  {i}. {s['icon']} {h:<10} {dim(s['hint'])}")

    def habit_check(t):
        names = list(HABITS)
        if t.isdigit() and 1 <= int(t) <= len(names):
            return []
        return [] if t.title() in HABITS else ["Pick 1-3 or type the habit name."]

    h_raw = ask_until_valid("Habit", habit_check)
    habit = list(HABITS)[int(h_raw) - 1] if h_raw.isdigit() else h_raw.title()
    spec = HABITS[habit]
    value = ask_until_valid(f"Amount in {spec['unit']}", lambda t: validate_entry(d, habit, t)[1])
    notes = ask_until_valid(f"Note (optional, max {MAX_NOTE_LEN} chars)",
                            lambda t: validate_entry(d, habit, value, t)[1])
    entry, _ = validate_entry(d, habit, value, notes)
    ok, msg = store.add(entry)
    if not ok:
        print(yellow(f"  ⚠ {msg}"))
        if confirm("  Replace the existing entry?"):
            ok, msg = store.add(entry, overwrite=True)
    if ok:
        print(green(f"  ✔ {msg} {spec['icon']} {habit}: {fmt(entry['value'])} {spec['unit']} on {entry['date']}"))
        if entry["value"] > spec["warn_high"]:
            print(red("  🚨 That value is unusually high – saved, but flagged."))
        elif entry["value"] >= spec["goal"]:
            print(green("  🎉 Goal reached!"))


def view_records(store: HabitStore):
    heading("Search records")
    kw = ask("Keyword (Enter = any)")
    hb = ask("Habit filter: 1=Reading 2=Exercise 3=Hydration (Enter = all)")
    habits = [list(HABITS)[int(hb) - 1]] if hb.isdigit() and 1 <= int(hb) <= 3 else None
    found = sorted(store.search(kw, habits), key=lambda r: (r["date"], r["habit"]), reverse=True)
    if not found:
        print(yellow("  No matching records."))
        return
    page, size = 0, 10
    while True:
        chunk = found[page * size:(page + 1) * size]
        table(["#", "Date", "Habit", "Amount", "Goal", "Note"],
              [(page * size + i + 1, r["date"], r["habit"],
                f"{fmt(r['value'])} {HABITS[r['habit']]['unit']}",
                "✔" if r["value"] >= HABITS[r["habit"]]["goal"] else "·", r["notes"])
               for i, r in enumerate(chunk)],
              [3, 10, 10, 10, 4, 30])
        total_pages = -(-len(found) // size)
        print(dim(f"\n  Page {page + 1}/{total_pages} · {len(found)} record(s)"))
        if page + 1 >= total_pages:
            break
        if ask("Enter = next page, q = stop").lower() == "q":
            break
        page += 1


def show_summary(store: HabitStore):
    end = pick_end_date()
    s = build_summary(store.records, end)
    heading(f"Weekly summary  {s['start']} → {s['end']}")
    tone = TONE[s["tone"]]
    print(f"  Overall: {tone(bold(s['status']))}  {tone(progress_bar(s['overall_pct']))} {s['overall_pct']:.0f}%")
    print(dim(f"  {s['entries']} entries · {s['perfect_days']} perfect day(s)\n"))
    rows = []
    for h, x in s["habits"].items():
        arrow = {"Improving": "↗", "Declining": "↘", "Steady": "→", "New": "•"}[x["trend"]]
        rows.append((f"{HABITS[h]['icon']} {h}", f"{fmt(x['total'])} {x['unit']}", f"{fmt(x['avg_per_day'])} {x['unit']}",
                     f"{x['goal_days']}/7", f"{x['streak']}d", f"{arrow} {x['trend']}", x["status"]))
    table(["Habit", "Total", "Avg/day", "Goals", "Streak", "Trend", "Status"], rows, [12, 12, 11, 6, 7, 12, 16])
    print()
    for h, x in s["habits"].items():
        print(f"  {h:<10} {TONE[x['tone']](progress_bar(x['goal_pct']))} {x['goal_pct']:.0f}%")
    show_warnings(store, end, heading_on=False)


def show_warnings(store: HabitStore, end: date | None = None, heading_on=True):
    end = end or today()
    ws = threshold_warnings(store.records, end)
    if heading_on:
        heading("Warnings")
    else:
        print()
    if not ws:
        print(green("  ✔ No warnings – everything looks healthy!"))
        return
    for w in ws:
        icon = {"critical": "🚨", "warning": "⏰", "info": "ℹ "}[w["level"]]
        print(LEVEL[w["level"]](f"  {icon} [{w['level'].upper()}] {w['date']} {w['habit']}: {w['message']}"))


def pick_end_date() -> date:
    def check(t):
        e = validate_entry(t, "Reading", 0)[1]
        return [x for x in e if "more than" not in x]
    t = ask_until_valid("Week ending (Enter = today)", check, today().isoformat())
    return datetime.strptime(t, "%Y-%m-%d").date()


def make_charts(store: HabitStore):
    heading("Charts")
    try:
        from habit_tracker import charts
        import matplotlib.pyplot as plt
    except ImportError:
        print(yellow("  matplotlib isn't installed – run: pip3 install matplotlib"))
        return
    end = pick_end_date()
    s = build_summary(store.records, end)
    EXPORT_DIR.mkdir(exist_ok=True)
    path = EXPORT_DIR / f"habit_charts_{end}.png"
    fig = charts.report_figure(s, store.records, end)
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    print(green(f"  ✔ Saved {path.relative_to(ROOT)}"))
    if confirm("  Open it now?"):
        webbrowser.open(path.as_uri())


def export_reports(store: HabitStore):
    heading("Export reports")
    end = pick_end_date()
    s = build_summary(store.records, end)
    w = threshold_warnings(store.records, end)
    EXPORT_DIR.mkdir(exist_ok=True)
    files = {
        f"habit_report_{end}.md": markdown_report(s, w),
        f"habit_audit_log_{end}.txt": text_report(s, w),
        f"habit_records_{end}.csv": records_csv(store.records),
    }
    for name, content in files.items():
        (EXPORT_DIR / name).write_text(content, encoding="utf-8")
        print(green(f"  ✔ exports/{name}"))


def import_csv(store: HabitStore):
    heading("Bulk import from CSV")
    p = ask("Path to CSV file", "data/legacy_import_with_errors.csv")
    path = Path(p).expanduser()
    if not path.is_absolute() and not path.exists():
        path = ROOT / p
    try:
        content = path.read_bytes()
    except OSError as e:
        print(red(f"  ✖ Can't read file: {e.strerror or e}"))
        return
    valid, log, stats = parse_csv_import(content, store.records)
    print(f"\n  Rows: {stats['total']} · {green('valid ' + str(stats['valid']))} · "
          f"{red('errors ' + str(stats['errors']))} · {yellow('duplicates ' + str(stats['duplicates']))}\n")
    bad = [e for e in log if e["status"] != "ok"]
    if bad:
        table(["Row", "Status", "Message"], [(e["row"], e["status"], e["message"]) for e in bad], [4, 10, 60])
        EXPORT_DIR.mkdir(exist_ok=True)
        (EXPORT_DIR / "import_log.csv").write_text(import_log_csv(log), encoding="utf-8")
        print(dim("\n  Full log saved to exports/import_log.csv"))
    if valid and confirm(f"\n  Import {len(valid)} valid row(s)?"):
        print(green(f"  ✔ Imported {store.import_rows(valid)} record(s)."))


def load_sample(store: HabitStore):
    heading("Load sample data")
    try:
        sample = json.loads(SAMPLE_JSON.read_text(encoding="utf-8"))["records"]
    except (OSError, ValueError, KeyError):
        print(red("  ✖ Sample file missing or unreadable."))
        return
    n = store.import_rows(shift_records_to_end(sample, today() - timedelta(days=1)), overwrite=True)
    print(green(f"  ✔ Loaded {n} sample records (dates shifted to end yesterday)."))


def delete_record(store: HabitStore):
    heading("Delete a record")
    recent = sorted(store.records, key=lambda r: (r["date"], r["habit"]), reverse=True)[:10]
    if not recent:
        print(yellow("  Nothing to delete."))
        return
    table(["#", "Date", "Habit", "Amount"],
          [(i, r["date"], r["habit"], f"{fmt(r['value'])} {HABITS[r['habit']]['unit']}") for i, r in enumerate(recent, 1)],
          [3, 10, 10, 12])
    pick = ask("Number to delete (Enter = cancel)")
    if pick.isdigit() and 1 <= int(pick) <= len(recent) and confirm("  Really delete?"):
        store.delete(recent[int(pick) - 1]["id"])
        print(green("  ✔ Deleted."))
    else:
        print(dim("  Cancelled."))


MENU = [
    ("1", "➕ Log a habit", log_habit),
    ("2", "🔎 Search records", view_records),
    ("3", "📊 Weekly summary", show_summary),
    ("4", "⚠️  Warnings", lambda s: show_warnings(s)),
    ("5", "📈 Save charts (PNG)", make_charts),
    ("6", "📤 Export reports", export_reports),
    ("7", "📥 Import CSV", import_csv),
    ("8", "🧪 Load sample data", load_sample),
    ("9", "🗑️  Delete a record", delete_record),
    ("0", "🚪 Exit", None),
]


def main():
    store = HabitStore(DATA_FILE)
    banner()
    for note in store.load_notes:
        print(yellow(f"  ⚠ {note}"))
    print(dim(f"  {len(store.records)} record(s) loaded from data/habits.json"))
    actions = {k: fn for k, _, fn in MENU}
    while True:
        print("\n" + bold("MENU"))
        for k, label, _ in MENU:
            print(f"  {cyan(k)}  {label}")
        try:
            choice = input(bold("\nChoose an option: ")).strip()
            if choice == "0":
                break
            if choice not in actions:
                print(red("  ✖ Please enter a number from the menu."))
                continue
            actions[choice](store)
        except KeyboardInterrupt:
            print(dim("\n  (cancelled)"))
        except EOFError:
            break
    print(green("\n  Goodbye – keep up the healthy habits! 🌿\n"))


if __name__ == "__main__":
    main()
