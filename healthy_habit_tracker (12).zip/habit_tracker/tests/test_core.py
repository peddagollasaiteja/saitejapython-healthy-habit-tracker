import json
import sys
import tempfile
import unittest
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from habit_tracker.core import (  # noqa: E402
    HabitStore, build_summary, current_streak, markdown_report, parse_csv_import, records_csv,
    shift_records_to_end, text_report, threshold_warnings, validate_entry,
)

TODAY = date(2026, 11, 26)
ROOT = Path(__file__).resolve().parent.parent


class ValidationTests(unittest.TestCase):
    def ok(self, *a):
        entry, errs = validate_entry(*a, ref_today=TODAY)
        self.assertEqual(errs, [], errs)
        return entry

    def bad(self, *a):
        entry, errs = validate_entry(*a, ref_today=TODAY)
        self.assertIsNone(entry)
        self.assertTrue(errs)
        return errs

    def test_valid_and_boundaries(self):
        self.assertEqual(self.ok("2026-11-25", "reading", "30")["value"], 30)
        self.assertEqual(self.ok("2026-11-25", "Reading", "0")["value"], 0)
        self.assertEqual(self.ok("2026-11-25", "Reading", "600")["value"], 600)
        self.assertEqual(self.ok("2026-11-25", "Hydration", "1,500")["value"], 1500)

    def test_rejects_bad_values(self):
        for v in ("", "  ", "abc", "nan", "inf", "-1", "601", True):
            self.bad("2026-11-25", "Reading", v)
        self.bad("2026-11-25", "Hydration", "8001")

    def test_rejects_bad_dates_and_habits(self):
        self.bad("2026-11-27", "Reading", 10)       # future
        self.bad("25/11/2026", "Reading", 10)       # format
        self.bad("2020-01-01", "Reading", 10)       # too old
        self.bad("2026-11-25", "Yoga", 10)          # unknown habit
        self.bad("", "Reading", 10)

    def test_notes_sanitised(self):
        e = self.ok("2026-11-25", "Reading", 10, "  hi\x00\n there  ")
        self.assertEqual(e["notes"], "hi there")
        self.bad("2026-11-25", "Reading", 10, "x" * 201)


class StoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "h.json"

    def tearDown(self):
        self.tmp.cleanup()

    def entry(self, d="2026-11-25", h="Reading", v=30, n=""):
        e, errs = validate_entry(d, h, v, n, ref_today=TODAY)
        assert not errs
        return e

    def test_missing_file_created(self):
        s = HabitStore(self.path)
        self.assertTrue(self.path.exists())
        self.assertEqual(s.records, [])

    def test_corrupt_file_recovered(self):
        self.path.write_text("{not json", encoding="utf-8")
        s = HabitStore(self.path)
        self.assertEqual(s.records, [])
        self.assertTrue(any("corrupt" in n.lower() for n in s.load_notes))
        self.assertTrue(list(Path(self.tmp.name).glob("*.corrupt-*")))

    def test_wrong_structure_and_bad_rows(self):
        self.path.write_text(json.dumps([1, 2]), encoding="utf-8")
        self.assertEqual(HabitStore(self.path).records, [])
        self.path.write_text(json.dumps({"records": [
            {"date": "2026-11-25", "habit": "Reading", "value": 20},
            {"date": "bad", "habit": "Reading", "value": 20}, "junk",
        ]}), encoding="utf-8")
        s = HabitStore(self.path)
        self.assertEqual(len(s.records), 1)

    def test_persistence_roundtrip_and_duplicates(self):
        s = HabitStore(self.path)
        self.assertTrue(s.add(self.entry())[0])
        self.assertFalse(s.add(self.entry(v=45))[0])
        self.assertTrue(s.add(self.entry(v=45), overwrite=True)[0])
        s2 = HabitStore(self.path)  # "restart"
        self.assertEqual(len(s2.records), 1)
        self.assertEqual(s2.records[0]["value"], 45)

    def test_search_and_delete(self):
        s = HabitStore(self.path)
        s.add(self.entry(n="Morning jog", h="Exercise"))
        s.add(self.entry(h="Reading", n="Novel"))
        self.assertEqual(len(s.search("jog")), 1)
        self.assertEqual(len(s.search("", ["Reading"])), 1)
        self.assertEqual(len(s.search("", None, date(2026, 11, 26), None)), 0)
        self.assertTrue(s.delete(s.records[0]["id"]))
        self.assertEqual(len(s.records), 1)


class AnalyticsTests(unittest.TestCase):
    def make(self):
        recs = []
        for i in range(7):
            d = (TODAY - timedelta(days=i)).isoformat()
            recs.append({"id": f"a{i}", "date": d, "habit": "Reading", "value": 30 if i < 5 else 10, "notes": ""})
        return recs

    def test_summary(self):
        s = build_summary(self.make(), TODAY)["habits"]["Reading"]
        self.assertEqual(s["total"], 170)
        self.assertEqual(s["goal_days"], 5)
        self.assertEqual(s["streak"], 5)
        self.assertEqual(s["status"], "Needs attention")  # 5/7 = 71%

    def test_empty_data(self):
        s = build_summary([], TODAY)
        self.assertEqual(s["overall_pct"], 0)
        self.assertEqual(s["habits"]["Exercise"]["trend"], "New")

    def test_streak_skips_empty_today(self):
        vals = {TODAY - timedelta(days=1): 40, TODAY - timedelta(days=2): 40}
        self.assertEqual(current_streak(vals, 30, TODAY), 2)

    def test_warnings(self):
        recs = [{"id": "x", "date": TODAY.isoformat(), "habit": "Hydration", "value": 6000, "notes": ""},
                {"id": "y", "date": TODAY.isoformat(), "habit": "Exercise", "value": 0, "notes": ""}]
        w = threshold_warnings(recs, TODAY)
        levels = {x["level"] for x in w}
        self.assertIn("critical", levels)
        self.assertTrue(any("overdue" in x["message"] for x in w))  # Reading never logged

    def test_reports(self):
        s = build_summary(self.make(), TODAY)
        self.assertIn("| Habit |", markdown_report(s, []))
        self.assertIn("AUDIT LOG", text_report(s, []))

    def test_csv_formula_injection(self):
        out = records_csv([{"id": "1", "date": "2026-11-25", "habit": "Reading", "value": 5, "notes": "=1+1"}])
        self.assertIn("'=1+1", out)


class ImportTests(unittest.TestCase):
    def test_legacy_file(self):
        text = (ROOT / "data" / "legacy_import_with_errors.csv").read_text(encoding="utf-8")
        valid, log, stats = parse_csv_import(text, ref_today=TODAY)
        self.assertEqual(stats["total"], 10)
        self.assertEqual(stats["valid"], 3)       # valid, valid, formula-note row
        self.assertEqual(stats["duplicates"], 1)
        self.assertEqual(stats["errors"], 6)
        self.assertEqual(log[1]["row"], 3)

    def test_missing_columns_and_binary(self):
        _, log, _ = parse_csv_import("a,b\n1,2\n")
        self.assertIn("Missing required", log[0]["message"])
        _, log, _ = parse_csv_import(b"\xff\xfe\x00bad")
        self.assertEqual(log[0]["status"], "error")


class SampleDataTests(unittest.TestCase):
    def test_sample_has_40_valid_entries(self):
        text = (ROOT / "data" / "sample_habits.csv").read_text(encoding="utf-8")
        valid, log, stats = parse_csv_import(text, ref_today=TODAY)
        self.assertEqual(stats["total"], 40)
        self.assertEqual(stats["errors"], 0, log)
        data = json.loads((ROOT / "data" / "sample_habits.json").read_text(encoding="utf-8"))
        self.assertEqual(len(data["records"]), 40)

    def test_shift(self):
        recs = json.loads((ROOT / "data" / "sample_habits.json").read_text(encoding="utf-8"))["records"]
        shifted = shift_records_to_end(recs, date(2027, 1, 10))
        self.assertEqual(max(r["date"] for r in shifted), "2027-01-10")


if __name__ == "__main__":
    unittest.main()
