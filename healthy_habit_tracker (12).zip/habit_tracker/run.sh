#!/usr/bin/env bash
# Create a virtualenv (first run), install deps, launch the app.
set -e
cd "$(dirname "$0")"
[ -d .venv ] || python3 -m venv .venv
. .venv/bin/activate
pip install -q -r requirements.txt
streamlit run app.py
