"""Core business logic: habit definitions, validation, persistence, analytics, reports.

Pure standard library (no Streamlit / Matplotlib imports) so it is easy to test.
"""
from __future__ import annotations

import csv
import io
import json
import math
import os
import re
import uuid
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Iterable

# --------------------------------------------------------------------------- #
# Habit definitions
# --------------------------------------------------------------------------- #
HABITS: dict[str, dict] = {
    "Reading": {
        "unit": "min", "goal": 30, "min": 0, "max": 600, "warn_high": 300,
        "icon": "📖", "color": "#7C5CFC", "step": 5,
        "hint": "Minutes spent reading (0 – 600)",
    },
    "Exercise": {
        "unit": "min", "goal": 30, "min": 0, "max": 300, "warn_high": 180,
        "icon": "🏃", "color": "#12B886", "step": 5,
        "hint": "Minutes of exercise (0 – 300)",
    },
    "Hydration": {
        "unit": "ml", "goal": 2000, "min": 0, "max": 8000, "warn_high": 5000,
        "icon": "💧", "color": "#228BE6", "step": 250,
        "hint": "Water intake in millilitres (0 – 8000)",
    },
}

MAX_NOTE_LEN = 200
MAX_BACKDATE_DAYS = 365
DATE_FMT = "%Y-%m-%d"
REQUIRED_IMPORT_COLUMNS = ("date", "habit", "value")


def today() -> date:
    return date.today()


# --------------------------------------------------------------------------- #
# Validation
# --------------------------------------------------------------------------- #
def validate_entry(raw_date, raw_habit, raw_value, raw_notes="", *, ref_today: date | None = None,
                   check_date_range: bool = True):
    """Validate and sanitise one entry.

    Returns ``(entry_dict | None, errors)``. ``entry_dict`` is only returned when
    ``errors`` is empty.
    """
    ref_today = ref_today or today()
    errors: list[str] = []

    # --- date -------------------------------------------------------------
    d: date | None = None
    if isinstance(raw_date, datetime):
        d = raw_date.date()
    elif isinstance(raw_date, date):
        d = raw_date
    else:
        text = str(raw_date or "").strip()
        if not text:
            errors.append("Date is required.")
        else:
            try:
                d = datetime.strptime(text, DATE_FMT).date()
            except ValueError:
                errors.append(f"Date '{text}' is not valid – use YYYY-MM-DD.")
    if d is not None and check_date_range:
        if d > ref_today:
            errors.append("Date cannot be in the future.")
        elif (ref_today - d).days > MAX_BACKDATE_DAYS:
            errors.append(f"Date is more than {MAX_BACKDATE_DAYS} days in the past.")

    # --- habit ------------------------------------------------------------
    habit = None
    h = str(raw_habit or "").strip().lower()
    for name in HABITS:
        if name.lower() == h:
            habit = name
    if habit is None:
        errors.append(f"Unknown habit '{raw_habit}'. Choose one of: {', '.join(HABITS)}.")

    # --- value ------------------------------------------------------------
    value = None
    if isinstance(raw_value, bool):
        errors.append("Value must be a number.")
    else:
        text = str(raw_value if raw_value is not None else "").strip().replace(",", "")
        if not text:
            errors.append("Value is required.")
        else:
            try:
                num = float(text)
                if math.isnan(num) or math.isinf(num):
                    raise ValueError
                value = round(num, 1)
                if value == int(value):
                    value = int(value)
            except ValueError:
                errors.append(f"Value '{raw_value}' is not a number.")
    if value is not None and habit is not None:
        spec = HABITS[habit]
        if value < spec["min"] or value > spec["max"]:
            errors.append(
                f"{habit} must be between {spec['min']} and {spec['max']} {spec['unit']} (got {value})."
            )

    # --- notes ------------------------------------------------------------
    notes = re.sub(r"[\x00-\x1f\x7f]+", " ", str(raw_notes or ""))
    notes = re.sub(r"\s+", " ", notes).strip()
    if len(notes) > MAX_NOTE_LEN:
        errors.append(f"Note is too long ({len(notes)} > {MAX_NOTE_LEN} characters).")

    if errors:
        return None, errors
    return {
        "id": uuid.uuid4().hex[:10],
        "date": d.strftime(DATE_FMT),
        "habit": habit,
        "value": value,
        "notes": notes,
    }, []


# --------------------------------------------------------------------------- #
# Persistence
# --------------------------------------------------------------------------- #
class HabitStore:
    """JSON-backed record store with corruption recovery and atomic writes."""

    def __init__(self, path: str | os.PathLike):
        self.path = Path(path)
        self.records: list[dict] = []
        self.load_notes: list[str] = []
        self.load()

    # -- load / save ------------------------------------------------------
    def load(self) -> None:
        self.records, self.load_notes = [], []
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            self.save()  # create a clean template
            self.load_notes.append("No data file found – created a fresh one.")
            return
        except (json.JSONDecodeError, UnicodeDecodeError):
            backup = self.path.with_suffix(f".corrupt-{datetime.now():%Y%m%d%H%M%S}.json")
            try:
                self.path.replace(backup)
                self.load_notes.append(f"Data file was corrupted. Backed up to {backup.name} and reset.")
            except OSError:
                self.load_notes.append("Data file was corrupted and has been reset.")
            self.save()
            return

        items = raw.get("records") if isinstance(raw, dict) else None
        if not isinstance(items, list):
            self.load_notes.append("Data file had an unexpected structure – starting fresh.")
            self.save()
            return

        dropped = 0
        seen: set[tuple[str, str]] = set()
        for item in items:
            if not isinstance(item, dict):
                dropped += 1
                continue
            entry, errs = validate_entry(
                item.get("date"), item.get("habit"), item.get("value"), item.get("notes", ""),
                check_date_range=False,  # stored history may be older than the entry window
            )
            key = (entry["date"], entry["habit"]) if entry else None
            if errs or key in seen:
                dropped += 1
                continue
            seen.add(key)
            entry["id"] = str(item.get("id") or entry["id"])
            self.records.append(entry)
        if dropped:
            self.load_notes.append(f"Skipped {dropped} invalid or duplicate record(s) while loading.")
        self.records.sort(key=lambda r: (r["date"], r["habit"]))

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        payload = {"version": 1, "records": self.records}
        tmp.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        tmp.replace(self.path)

    # -- mutation ---------------------------------------------------------
    def _find(self, d: str, habit: str) -> int | None:
        for i, r in enumerate(self.records):
            if r["date"] == d and r["habit"] == habit:
                return i
        return None

    def add(self, entry: dict, overwrite: bool = False) -> tuple[bool, str]:
        idx = self._find(entry["date"], entry["habit"])
        if idx is not None:
            if not overwrite:
                return False, f"{entry['habit']} already logged for {entry['date']}. Tick 'replace' to overwrite."
            entry = {**entry, "id": self.records[idx]["id"]}
            self.records[idx] = entry
            msg = "Entry updated."
        else:
            self.records.append(entry)
            msg = "Entry saved."
        self.records.sort(key=lambda r: (r["date"], r["habit"]))
        self.save()
        return True, msg

    def delete(self, record_id: str) -> bool:
        before = len(self.records)
        self.records = [r for r in self.records if r["id"] != record_id]
        if len(self.records) != before:
            self.save()
            return True
        return False

    def clear(self) -> None:
        self.records = []
        self.save()

    def import_rows(self, rows: list[dict], overwrite: bool = False) -> int:
        added = 0
        for entry in rows:
            ok, _ = self.add_no_save(entry, overwrite)
            added += ok
        self.records.sort(key=lambda r: (r["date"], r["habit"]))
        self.save()
        return added

    def add_no_save(self, entry: dict, overwrite: bool) -> tuple[bool, str]:
        idx = self._find(entry["date"], entry["habit"])
        if idx is not None:
            if not overwrite:
                return False, "duplicate"
            entry = {**entry, "id": self.records[idx]["id"]}
            self.records[idx] = entry
            return True, "updated"
        self.records.append(entry)
        return True, "added"

    # -- query ------------------------------------------------------------
    def search(self, keyword: str = "", habits: Iterable[str] | None = None,
               start: date | None = None, end: date | None = None) -> list[dict]:
        kw = (keyword or "").strip().lower()
        habit_set = set(habits) if habits else None
        out = []
        for r in self.records:
            if habit_set is not None and r["habit"] not in habit_set:
                continue
            d = datetime.strptime(r["date"], DATE_FMT).date()
            if start and d < start:
                continue
            if end and d > end:
                continue
            if kw and kw not in f"{r['notes']} {r['habit']} {r['date']} {r['value']}".lower():
                continue
            out.append(r)
        return out


# --------------------------------------------------------------------------- #
# Bulk import
# --------------------------------------------------------------------------- #
def parse_csv_import(content: str | bytes, existing: Iterable[dict] = (), *, ref_today: date | None = None):
    """Validate a legacy CSV. Returns (valid_entries, row_log, stats).

    ``row_log`` is a list of ``{"row": n, "status": "ok|error|duplicate", "message": str}``.
    """
    if isinstance(content, bytes):
        try:
            content = content.decode("utf-8-sig")
        except UnicodeDecodeError:
            return [], [{"row": 0, "status": "error", "message": "File is not valid UTF-8 text."}], \
                {"total": 0, "valid": 0, "errors": 1, "duplicates": 0}

    reader = csv.DictReader(io.StringIO(content))
    fields = [f.strip().lower() for f in (reader.fieldnames or [])]
    missing = [c for c in REQUIRED_IMPORT_COLUMNS if c not in fields]
    if missing:
        msg = f"Missing required column(s): {', '.join(missing)}. Expected: date, habit, value[, notes]."
        return [], [{"row": 1, "status": "error", "message": msg}], \
            {"total": 0, "valid": 0, "errors": 1, "duplicates": 0}

    taken = {(r["date"], r["habit"]) for r in existing}
    valid, log = [], []
    dup = 0
    total = 0
    for n, row in enumerate(reader, start=2):  # header is row 1
        row = {(k or "").strip().lower(): v for k, v in row.items()}
        if not any((v or "").strip() for k, v in row.items() if k):
            continue  # blank line
        total += 1
        entry, errs = validate_entry(row.get("date"), row.get("habit"), row.get("value"),
                                     row.get("notes", ""), ref_today=ref_today)
        if errs:
            log.append({"row": n, "status": "error", "message": " ".join(errs)})
            continue
        key = (entry["date"], entry["habit"])
        if key in taken:
            dup += 1
            log.append({"row": n, "status": "duplicate",
                        "message": f"{entry['habit']} on {entry['date']} already exists – skipped."})
            continue
        taken.add(key)
        valid.append(entry)
        log.append({"row": n, "status": "ok", "message": "Valid"})
    errors = sum(1 for e in log if e["status"] == "error")
    return valid, log, {"total": total, "valid": len(valid), "errors": errors, "duplicates": dup}


# --------------------------------------------------------------------------- #
# Analytics
# --------------------------------------------------------------------------- #
def _d(s: str) -> date:
    return datetime.strptime(s, DATE_FMT).date()


def daily_values(records: Iterable[dict], habit: str) -> dict[date, float]:
    out: dict[date, float] = {}
    for r in records:
        if r["habit"] == habit:
            out[_d(r["date"])] = out.get(_d(r["date"]), 0) + r["value"]
    return out


def date_range(end: date, days: int) -> list[date]:
    return [end - timedelta(days=i) for i in range(days - 1, -1, -1)]


def current_streak(values: dict[date, float], goal: float, end: date) -> int:
    """Consecutive goal-meeting days ending at ``end`` (or the day before if ``end`` is unmet/empty)."""
    day = end
    if values.get(day, 0) < goal:
        day -= timedelta(days=1)
    streak = 0
    while values.get(day, 0) >= goal:
        streak += 1
        day -= timedelta(days=1)
    return streak


def status_for(pct: float) -> tuple[str, str]:
    if pct >= 80:
        return "On track", "good"
    if pct >= 50:
        return "Needs attention", "warn"
    return "Off track", "bad"


def habit_summary(records: list[dict], habit: str, end: date, days: int = 7) -> dict:
    spec = HABITS[habit]
    vals = daily_values(records, habit)
    window = date_range(end, days)
    prev_window = date_range(end - timedelta(days=days), days)
    series = [vals.get(d, 0) for d in window]
    logged = [vals[d] for d in window if d in vals]
    total = sum(series)
    goal_days = sum(1 for v in series if v >= spec["goal"])
    pct = goal_days / days * 100
    prev_total = sum(vals.get(d, 0) for d in prev_window)
    prev_logged = any(d in vals for d in prev_window)
    if not prev_logged:
        trend, change = "New", None
    else:
        change = ((total - prev_total) / prev_total * 100) if prev_total else None
        if change is None:
            trend = "Improving" if total > 0 else "Steady"
        elif change > 10:
            trend = "Improving"
        elif change < -10:
            trend = "Declining"
        else:
            trend = "Steady"
    status, tone = status_for(pct)
    best_day = max(window, key=lambda d: vals.get(d, 0)) if logged else None
    return {
        "habit": habit, "unit": spec["unit"], "goal": spec["goal"],
        "total": total,
        "avg_per_day": round(total / days, 1),
        "avg_logged": round(sum(logged) / len(logged), 1) if logged else 0,
        "days_logged": len(logged),
        "goal_days": goal_days, "goal_pct": round(pct, 1),
        "best_value": vals.get(best_day, 0) if best_day else 0,
        "best_day": best_day.strftime(DATE_FMT) if best_day else None,
        "streak": current_streak(vals, spec["goal"], end),
        "trend": trend, "change_pct": None if change is None else round(change, 1),
        "status": status, "tone": tone,
        "today_value": vals.get(end, 0),
        "series": list(zip(window, series)),
    }


def build_summary(records: list[dict], end: date, days: int = 7) -> dict:
    per = {h: habit_summary(records, h, end, days) for h in HABITS}
    overall_pct = sum(s["goal_pct"] for s in per.values()) / len(per)
    status, tone = status_for(overall_pct)
    window = date_range(end, days)
    entries = sum(1 for r in records if window[0] <= _d(r["date"]) <= end)
    perfect = sum(
        1 for d in window
        if all(dict(per[h]["series"]).get(d, 0) >= HABITS[h]["goal"] for h in HABITS)
    )
    return {
        "end": end.strftime(DATE_FMT), "start": window[0].strftime(DATE_FMT), "days": days,
        "habits": per, "overall_pct": round(overall_pct, 1), "status": status, "tone": tone,
        "entries": entries, "perfect_days": perfect,
    }


def threshold_warnings(records: list[dict], end: date, days: int = 7) -> list[dict]:
    """Console-style warning flags: anomalous, missed and overdue habits."""
    out: list[dict] = []
    window = date_range(end, days)
    lo, hi = window[0], window[-1]
    for r in records:
        d = _d(r["date"])
        if not (lo <= d <= hi):
            continue
        spec = HABITS[r["habit"]]
        if r["value"] > spec["warn_high"]:
            out.append({"level": "critical", "habit": r["habit"], "date": r["date"],
                        "message": f"Unusually high {r['habit'].lower()} ({r['value']} {spec['unit']}) – please double-check."})
        elif r["value"] == 0:
            out.append({"level": "info", "habit": r["habit"], "date": r["date"],
                        "message": f"Logged 0 {spec['unit']} – a missed day."})
    for h, spec in HABITS.items():
        vals = daily_values(records, h)
        recent = [end - timedelta(days=i) for i in range(3)]
        if not any(d in vals for d in recent):
            out.append({"level": "warning", "habit": h, "date": end.strftime(DATE_FMT),
                        "message": f"No {h.lower()} logged in the last 3 days – overdue."})
        else:
            last3 = [vals.get(d, 0) for d in recent]
            if all(v < spec["goal"] for v in last3):
                out.append({"level": "warning", "habit": h, "date": end.strftime(DATE_FMT),
                            "message": f"{h} goal missed 3 days in a row."})
    order = {"critical": 0, "warning": 1, "info": 2}
    out.sort(key=lambda w: (order[w["level"]], w["date"]))
    return out


# --------------------------------------------------------------------------- #
# Reports / exports
# --------------------------------------------------------------------------- #
def _fmt(v) -> str:
    return f"{v:,.1f}".rstrip("0").rstrip(".") if isinstance(v, float) else f"{v:,}"


def markdown_report(summary: dict, warnings: list[dict]) -> str:
    lines = [
        "# Healthy Habit Tracker – Weekly Report", "",
        f"**Period:** {summary['start']} → {summary['end']} ({summary['days']} days)  ",
        f"**Overall status:** {summary['status']} ({summary['overall_pct']}% of daily goals met)  ",
        f"**Entries logged:** {summary['entries']} · **Perfect days:** {summary['perfect_days']}", "",
        "## Habit summary", "",
        "| Habit | Total | Avg / day | Goal days | Streak | Trend | Status |",
        "|---|---:|---:|---:|---:|---|---|",
    ]
    for h, s in summary["habits"].items():
        lines.append(
            f"| {HABITS[h]['icon']} {h} | {_fmt(s['total'])} {s['unit']} | {_fmt(s['avg_per_day'])} {s['unit']} "
            f"| {s['goal_days']}/{summary['days']} | {s['streak']} | {s['trend']} | {s['status']} |"
        )
    lines += ["", "## Warnings", ""]
    lines += [f"- **{w['level'].upper()}** ({w['habit']}, {w['date']}): {w['message']}" for w in warnings] or ["- None 🎉"]
    return "\n".join(lines) + "\n"


def text_report(summary: dict, warnings: list[dict]) -> str:
    bar = "=" * 64
    lines = [bar, "HEALTHY HABIT TRACKER – AUDIT LOG", bar,
             f"Generated : {datetime.now():%Y-%m-%d %H:%M}",
             f"Period    : {summary['start']} to {summary['end']}",
             f"Overall   : {summary['status']} ({summary['overall_pct']}%)",
             f"Entries   : {summary['entries']}   Perfect days: {summary['perfect_days']}", "", "-" * 64,
             f"{'Habit':<11}{'Total':>12}{'Avg/day':>11}{'Goal days':>11}{'Streak':>8}  Status", "-" * 64]
    for h, s in summary["habits"].items():
        lines.append(f"{h:<11}{_fmt(s['total']) + ' ' + s['unit']:>12}{_fmt(s['avg_per_day']):>11}"
                     f"{str(s['goal_days']) + '/' + str(summary['days']):>11}{s['streak']:>8}  {s['status']}")
    lines += ["", "WARNINGS"]
    lines += [f"  [{w['level'].upper():8}] {w['date']} {w['habit']}: {w['message']}" for w in warnings] or ["  none"]
    return "\n".join(lines) + "\n"


def _csv_safe(text: str) -> str:
    """Neutralise spreadsheet formula injection."""
    return "'" + text if text and text[0] in "=+-@" else text


def records_csv(records: Iterable[dict]) -> str:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["date", "habit", "value", "unit", "notes"])
    for r in sorted(records, key=lambda r: (r["date"], r["habit"])):
        w.writerow([r["date"], r["habit"], r["value"], HABITS[r["habit"]]["unit"], _csv_safe(r["notes"])])
    return buf.getvalue()


def import_log_csv(log: list[dict]) -> str:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["row", "status", "message"])
    for e in log:
        w.writerow([e["row"], e["status"], e["message"]])
    return buf.getvalue()


def shift_records_to_end(records: list[dict], new_end: date) -> list[dict]:
    """Shift a dataset's dates so its latest day lands on ``new_end`` (for demo data)."""
    if not records:
        return []
    delta = new_end - max(_d(r["date"]) for r in records)
    return [{**r, "date": (_d(r["date"]) + delta).strftime(DATE_FMT)} for r in records]
