"""Matplotlib charts (Agg backend) – return Figure objects."""
from __future__ import annotations

from datetime import date, timedelta

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.colors import ListedColormap  # noqa: E402

from .core import HABITS, daily_values, date_range  # noqa: E402

INK = "#1F2544"
MUTED = "#8A90A9"
GRID = "#E8EAF3"


def _style(ax):
    for s in ("top", "right", "left"):
        ax.spines[s].set_visible(False)
    ax.spines["bottom"].set_color(GRID)
    ax.tick_params(colors=MUTED, labelsize=9, length=0)
    ax.grid(axis="y", color=GRID, linewidth=1)
    ax.set_axisbelow(True)


def trend_chart(records, habit: str, end: date, days: int = 14):
    spec = HABITS[habit]
    vals = daily_values(records, habit)
    window = date_range(end, days)
    ys = [vals.get(d, 0) for d in window]
    fig, ax = plt.subplots(figsize=(8, 3.3), dpi=140)
    _style(ax)
    ax.fill_between(window, ys, color=spec["color"], alpha=0.14)
    ax.plot(window, ys, color=spec["color"], linewidth=2.6, marker="o", markersize=5,
            markerfacecolor="white", markeredgewidth=2)
    ax.axhline(spec["goal"], color=INK, linestyle=(0, (4, 4)), linewidth=1.2, alpha=0.6)
    ax.text(window[0], spec["goal"], f"  goal {spec['goal']} {spec['unit']}", color=INK,
            fontsize=8.5, va="bottom", alpha=0.8)
    ax.set_ylim(bottom=0)
    ax.set_title(f"{habit} · last {days} days ({spec['unit']})",
                 loc="left", color=INK, fontsize=12, fontweight="bold", pad=12)
    ax.xaxis.set_major_formatter(matplotlib.dates.DateFormatter("%d %b"))
    fig.autofmt_xdate(rotation=0, ha="center")
    fig.tight_layout()
    return fig


def goal_completion_chart(summary: dict):
    names = list(summary["habits"])
    pcts = [summary["habits"][h]["goal_pct"] for h in names]
    colors = [HABITS[h]["color"] for h in names]
    fig, ax = plt.subplots(figsize=(6, 3.3), dpi=140)
    _style(ax)
    ax.grid(axis="y", visible=False)
    ax.grid(axis="x", color=GRID)
    bars = ax.barh(names, [100] * len(names), color=GRID, height=0.5)
    bars = ax.barh(names, pcts, color=colors, height=0.5)
    for b, p in zip(bars, pcts):
        ax.text(min(p + 2, 88), b.get_y() + b.get_height() / 2, f"{p:.0f}%", va="center",
                color=INK, fontsize=10, fontweight="bold")
    ax.set_xlim(0, 105)
    ax.invert_yaxis()
    ax.set_title("Goal completion this week", loc="left", color=INK, fontsize=12, fontweight="bold", pad=12)
    fig.tight_layout()
    return fig


def consistency_heatmap(records, end: date, days: int = 14):
    window = date_range(end, days)
    names = list(HABITS)
    grid = []
    for h in names:
        vals = daily_values(records, h)
        row = []
        for d in window:
            if d not in vals:
                row.append(0)
            elif vals[d] >= HABITS[h]["goal"]:
                row.append(2)
            else:
                row.append(1)
        grid.append(row)
    fig, ax = plt.subplots(figsize=(8, 2.6), dpi=140)
    cmap = ListedColormap(["#EEF0F7", "#FFD8A8", "#38D9A9"])
    ax.imshow(grid, cmap=cmap, aspect="auto", vmin=0, vmax=2)
    ax.set_xticks(range(days))
    ax.set_xticklabels([d.strftime("%d") for d in window], fontsize=8, color=MUTED)
    ax.set_yticks(range(len(names)))
    ax.set_yticklabels(names, fontsize=10, color=INK)
    ax.set_xticks([i - 0.5 for i in range(days + 1)], minor=True)
    ax.set_yticks([i - 0.5 for i in range(len(names) + 1)], minor=True)
    ax.grid(which="minor", color="white", linewidth=3)
    ax.tick_params(which="both", length=0)
    for s in ax.spines.values():
        s.set_visible(False)
    ax.set_title("Consistency  ·  green = goal met · amber = logged, below goal · grey = nothing",
                 loc="left", color=INK, fontsize=10, fontweight="bold", pad=10)
    fig.tight_layout()
    return fig


def distribution_chart(records, habit: str):
    spec = HABITS[habit]
    values = [r["value"] for r in records if r["habit"] == habit]
    fig, ax = plt.subplots(figsize=(6, 3.3), dpi=140)
    _style(ax)
    if values:
        ax.hist(values, bins=min(10, max(3, len(set(values)))), color=spec["color"], alpha=0.85,
                edgecolor="white", linewidth=1.5)
        ax.axvline(spec["goal"], color=INK, linestyle=(0, (4, 4)), linewidth=1.2)
    else:
        ax.text(0.5, 0.5, "No data yet", ha="center", va="center", color=MUTED, transform=ax.transAxes)
    ax.set_title(f"{habit} distribution ({spec['unit']}, all time)", loc="left", color=INK,
                 fontsize=12, fontweight="bold", pad=12)
    fig.tight_layout()
    return fig


def report_figure(summary: dict, records, end: date):
    """One combined PNG for export."""
    fig, axes = plt.subplots(2, 2, figsize=(12, 7.5), dpi=130)
    for ax, h in zip(axes.flat[:3], HABITS):
        spec = HABITS[h]
        vals = daily_values(records, h)
        window = date_range(end, summary["days"] * 2)
        ys = [vals.get(d, 0) for d in window]
        _style(ax)
        ax.fill_between(window, ys, color=spec["color"], alpha=0.14)
        ax.plot(window, ys, color=spec["color"], linewidth=2.4)
        ax.axhline(spec["goal"], color=INK, linestyle=(0, (4, 4)), linewidth=1, alpha=0.6)
        ax.set_title(f"{h} ({spec['unit']})", loc="left", color=INK, fontweight="bold")
        ax.xaxis.set_major_formatter(matplotlib.dates.DateFormatter("%d %b"))
        ax.tick_params(axis="x", labelsize=7)
    ax = axes.flat[3]
    names = list(summary["habits"])
    _style(ax)
    ax.bar(names, [summary["habits"][h]["goal_pct"] for h in names],
           color=[HABITS[h]["color"] for h in names], width=0.5)
    ax.set_ylim(0, 105)
    ax.set_title("Goal completion %", loc="left", color=INK, fontweight="bold")
    fig.suptitle(f"Healthy Habit Tracker · {summary['start']} → {summary['end']}",
                 color=INK, fontsize=14, fontweight="bold", x=0.02, ha="left")
    fig.tight_layout(rect=(0, 0, 1, 0.95))
    return fig
