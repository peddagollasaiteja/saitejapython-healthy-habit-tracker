"""Healthy Habit Tracker – Streamlit interface.

Run with:  streamlit run app.py
"""
from __future__ import annotations

import json
from datetime import timedelta
from io import BytesIO
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import streamlit as st

from habit_tracker import charts
from habit_tracker.core import (
    HABITS, MAX_BACKDATE_DAYS, MAX_NOTE_LEN, HabitStore, build_summary, import_log_csv,
    markdown_report, parse_csv_import, records_csv, shift_records_to_end, text_report,
    threshold_warnings, today, validate_entry,
)

ROOT = Path(__file__).resolve().parent
DATA_FILE = ROOT / "data" / "habits.json"
SAMPLE_JSON = ROOT / "data" / "sample_habits.json"

st.set_page_config(page_title="Healthy Habit Tracker", page_icon="🌿", layout="wide")

# --------------------------------------------------------------------------- #
# Styling
# --------------------------------------------------------------------------- #
st.markdown(
    """
<style>
@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
html, body, [class*="css"], .stMarkdown, button, input, textarea { font-family: 'Plus Jakarta Sans', sans-serif; }
.block-container { padding-top: 1.6rem; max-width: 1200px; }
.hero {
  background: linear-gradient(120deg, #1F2544 0%, #3B3F8F 55%, #12B886 130%);
  border-radius: 22px; padding: 28px 32px; color: #fff; margin-bottom: 22px;
  box-shadow: 0 14px 40px rgba(59,63,143,.25); position: relative; overflow: hidden;
}
.hero:after { content:""; position:absolute; right:-60px; top:-60px; width:240px; height:240px;
  background: radial-gradient(circle, rgba(255,255,255,.18), transparent 70%); border-radius:50%; }
.hero h1 { margin: 0 0 4px 0; font-size: 2rem; font-weight: 800; color:#fff; padding:0; }
.hero p { margin: 0; opacity: .85; font-size: 1rem; }
.hero .pill { display:inline-block; margin-top:14px; padding:6px 14px; border-radius:999px;
  background: rgba(255,255,255,.16); font-weight:600; font-size:.85rem; backdrop-filter: blur(4px); }
.card {
  background: #fff; border: 1px solid #E8EAF3; border-radius: 18px; padding: 20px 20px 16px;
  box-shadow: 0 4px 18px rgba(31,37,68,.06); height: 100%;
}
.card .top { display:flex; align-items:center; justify-content:space-between; }
.card .name { font-weight:700; color:#1F2544; font-size:1.05rem; }
.card .big { font-size: 2rem; font-weight: 800; color:#1F2544; line-height:1.1; margin-top: 10px; }
.card .big small { font-size:.9rem; font-weight:600; color:#8A90A9; }
.card .sub { color:#8A90A9; font-size:.82rem; margin-top:2px; }
.bar { height:9px; background:#EEF0F7; border-radius:99px; margin:14px 0 12px; overflow:hidden; }
.bar > div { height:100%; border-radius:99px; }
.row { display:flex; gap:8px; flex-wrap:wrap; }
.chip { padding:3px 10px; border-radius:99px; font-size:.75rem; font-weight:700; }
.chip.good { background:#D3F9E8; color:#087F5B; }
.chip.warn { background:#FFF0D6; color:#B35C00; }
.chip.bad  { background:#FFE0E0; color:#C92A2A; }
.chip.neutral { background:#EEF0F7; color:#4A5070; }
.warnbox { border-radius:14px; padding:12px 16px; margin-bottom:8px; font-size:.92rem; font-weight:500; }
.warnbox.critical { background:#FFF0F0; border-left:5px solid #FA5252; color:#7A1F1F; }
.warnbox.warning  { background:#FFF8E6; border-left:5px solid #FAB005; color:#6B4A00; }
.warnbox.info     { background:#EEF4FF; border-left:5px solid #4C6EF5; color:#243B86; }
.section { font-size:1.15rem; font-weight:800; color:#1F2544; margin: 26px 0 10px; }
section[data-testid="stSidebar"] { background: #F6F7FC; }
div[data-testid="stMetric"] { background:#fff; border:1px solid #E8EAF3; border-radius:16px; padding:14px 16px; }
.stButton > button, .stDownloadButton > button, .stFormSubmitButton > button { border-radius: 12px; font-weight:700; }
</style>
""",
    unsafe_allow_html=True,
)

# --------------------------------------------------------------------------- #
# State
# --------------------------------------------------------------------------- #
store = HabitStore(DATA_FILE)
records = store.records

st.sidebar.markdown("## 🌿 Habit Tracker")
page = st.sidebar.radio(
    "Navigate",
    ["📊 Dashboard", "➕ Log a habit", "🔎 Records", "📈 Insights", "📦 Import & Export"],
    label_visibility="collapsed",
)
st.sidebar.markdown("---")
end_date = st.sidebar.date_input("Week ending", value=today(), max_value=today(),
                                 min_value=today() - timedelta(days=MAX_BACKDATE_DAYS))
st.sidebar.caption(f"{len(records)} records stored · `data/habits.json`")
for note in store.load_notes:
    st.sidebar.warning(note)

summary = build_summary(records, end_date)
warnings_ = threshold_warnings(records, end_date)


def hero(title: str, subtitle: str, pill: str | None = None):
    pill_html = f'<div class="pill">{pill}</div>' if pill else ""
    st.markdown(f'<div class="hero"><h1>{title}</h1><p>{subtitle}</p>{pill_html}</div>', unsafe_allow_html=True)


def fmt(v) -> str:
    return f"{v:,.1f}".rstrip("0").rstrip(".") if isinstance(v, float) else f"{v:,}"


def fig_png(fig) -> bytes:
    buf = BytesIO()
    fig.savefig(buf, format="png", bbox_inches="tight")
    return buf.getvalue()


def show(fig):
    st.pyplot(fig)
    plt.close(fig)


# --------------------------------------------------------------------------- #
# Pages
# --------------------------------------------------------------------------- #
if page == "📊 Dashboard":
    hero(
        "Healthy Habit Tracker",
        "Reading, exercise & hydration – tracked, validated and summarised for your week.",
        f"This week · {summary['start']} → {summary['end']} · {summary['status']} · {summary['overall_pct']:.0f}% of goals met",
    )

    if not records:
        st.info("No data yet. Log your first habit from the sidebar, or load the demo dataset in **Import & Export**.")

    cols = st.columns(3)
    for col, (h, s) in zip(cols, summary["habits"].items()):
        spec = HABITS[h]
        pct_today = min(100, s["today_value"] / spec["goal"] * 100)
        change = "" if s["change_pct"] is None else f" ({s['change_pct']:+.0f}%)"
        arrow = {"Improving": "↗", "Declining": "↘", "Steady": "→", "New": "•"}[s["trend"]]
        col.markdown(
            f"""
<div class="card">
  <div class="top"><span class="name">{spec['icon']} {h}</span><span class="chip {s['tone']}">{s['status']}</span></div>
  <div class="big">{fmt(s['total'])} <small>{s['unit']} this week</small></div>
  <div class="sub">avg {fmt(s['avg_per_day'])} {s['unit']}/day · goal {fmt(s['goal'])} {s['unit']}</div>
  <div class="bar"><div style="width:{pct_today:.0f}%;background:{spec['color']}"></div></div>
  <div class="sub">Latest day: {fmt(s['today_value'])} / {fmt(s['goal'])} {s['unit']}</div>
  <div class="row" style="margin-top:12px">
    <span class="chip neutral">🎯 {s['goal_days']}/7 days</span>
    <span class="chip neutral">🔥 {s['streak']} day streak</span>
    <span class="chip neutral">{arrow} {s['trend']}{change}</span>
  </div>
</div>""",
            unsafe_allow_html=True,
        )

    st.markdown('<div class="section">⚠️ Alerts</div>', unsafe_allow_html=True)
    if warnings_:
        for w in warnings_[:8]:
            icon = {"critical": "🚨", "warning": "⏰", "info": "ℹ️"}[w["level"]]
            st.markdown(f'<div class="warnbox {w["level"]}">{icon} <b>{w["habit"]}</b> · {w["date"]} — {w["message"]}</div>',
                        unsafe_allow_html=True)
        if len(warnings_) > 8:
            st.caption(f"+ {len(warnings_) - 8} more in the exported report.")
    else:
        st.success("No warnings – everything looks healthy! 🎉")

    c1, c2 = st.columns([1.35, 1])
    with c1:
        st.markdown('<div class="section">Consistency</div>', unsafe_allow_html=True)
        show(charts.consistency_heatmap(records, end_date, 14))
    with c2:
        st.markdown('<div class="section">Goal completion</div>', unsafe_allow_html=True)
        show(charts.goal_completion_chart(summary))

elif page == "➕ Log a habit":
    hero("Log a habit", "Every field is validated before it is saved – try a bad value to see how it's caught.")
    left, right = st.columns([1.1, 1])
    with left:
        with st.form("log_form", clear_on_submit=False):
            d = st.date_input("Date", value=today(), max_value=today(),
                              min_value=today() - timedelta(days=MAX_BACKDATE_DAYS))
            habit = st.selectbox("Habit", list(HABITS), format_func=lambda h: f"{HABITS[h]['icon']}  {h}")
            value = st.text_input("Amount", placeholder="e.g. 30 (minutes) or 2000 (ml)",
                                  help="Reading/Exercise in minutes, Hydration in millilitres.")
            notes = st.text_input("Note (optional)", max_chars=MAX_NOTE_LEN + 100, placeholder="How did it go?")
            replace = st.checkbox("Replace an existing entry for the same day & habit")
            submitted = st.form_submit_button("Save entry", type="primary")
        if submitted:
            entry, errs = validate_entry(d, habit, value, notes)
            if errs:
                for e in errs:
                    st.error(e)
            else:
                ok, msg = store.add(entry, overwrite=replace)
                (st.success if ok else st.warning)(
                    f"{HABITS[habit]['icon']} {msg} — {habit}: {fmt(entry['value'])} {HABITS[habit]['unit']} on {entry['date']}"
                )
                if ok:
                    spec = HABITS[habit]
                    if entry["value"] > spec["warn_high"]:
                        st.warning("That's unusually high – saved, but flagged on the dashboard.")
                    elif entry["value"] >= spec["goal"]:
                        st.balloons()
    with right:
        st.markdown('<div class="section" style="margin-top:0">Valid ranges & goals</div>', unsafe_allow_html=True)
        for h, spec in HABITS.items():
            st.markdown(
                f'<div class="card" style="margin-bottom:10px"><div class="name">{spec["icon"]} {h}</div>'
                f'<div class="sub">{spec["hint"]}</div>'
                f'<div class="row" style="margin-top:8px"><span class="chip good">Daily goal {fmt(spec["goal"])} {spec["unit"]}</span>'
                f'<span class="chip warn">Flag above {fmt(spec["warn_high"])} {spec["unit"]}</span></div></div>',
                unsafe_allow_html=True,
            )

elif page == "🔎 Records":
    hero("Records", "Search by keyword, habit and date range. Everything is stored locally in JSON.")
    f1, f2, f3 = st.columns([1.3, 1.3, 1.2])
    kw = f1.text_input("Keyword", placeholder="note text, date, value…")
    chosen = f2.multiselect("Habit", list(HABITS), default=list(HABITS))
    rng = f3.date_input("Date range", value=(today() - timedelta(days=30), today()), max_value=today())
    start, stop = (rng if isinstance(rng, tuple) and len(rng) == 2 else (None, None))
    found = store.search(kw, chosen, start, stop)
    found = sorted(found, key=lambda r: (r["date"], r["habit"]), reverse=True)
    st.caption(f"{len(found)} matching record(s)")

    if found:
        page_size = st.select_slider("Rows per page", [10, 20, 50], value=10)
        pages = max(1, -(-len(found) // page_size))
        pg = st.number_input("Page", 1, pages, 1) if pages > 1 else 1
        chunk = found[(pg - 1) * page_size: pg * page_size]
        df = pd.DataFrame(
            [{"Date": r["date"], "Habit": f"{HABITS[r['habit']]['icon']} {r['habit']}",
              "Amount": f"{fmt(r['value'])} {HABITS[r['habit']]['unit']}",
              "Goal met": "✅" if r["value"] >= HABITS[r["habit"]]["goal"] else "—",
              "Note": r["notes"]} for r in chunk]
        )
        st.dataframe(df, hide_index=True)
        with st.expander("🗑️ Delete a record"):
            options = {f"{r['date']} · {r['habit']} · {fmt(r['value'])} {HABITS[r['habit']]['unit']}": r["id"] for r in chunk}
            pick = st.selectbox("Choose record", list(options))
            if st.button("Delete selected"):
                store.delete(options[pick])
                st.rerun()
    else:
        st.info("Nothing matches those filters.")

elif page == "📈 Insights":
    hero("Insights", "Totals, averages, trends and charts for the selected week.",
         f"{summary['entries']} entries · {summary['perfect_days']} perfect day(s)")
    rows = []
    for h, s in summary["habits"].items():
        rows.append({
            "Habit": f"{HABITS[h]['icon']} {h}", "Total": f"{fmt(s['total'])} {s['unit']}",
            "Avg / day": f"{fmt(s['avg_per_day'])} {s['unit']}", "Avg (logged days)": f"{fmt(s['avg_logged'])} {s['unit']}",
            "Best day": f"{fmt(s['best_value'])} {s['unit']} ({s['best_day'] or '–'})",
            "Goal days": f"{s['goal_days']}/7", "Streak": s["streak"],
            "Trend": s["trend"] + ("" if s["change_pct"] is None else f" ({s['change_pct']:+.0f}%)"),
            "Status": s["status"],
        })
    st.dataframe(pd.DataFrame(rows), hide_index=True)

    tabs = st.tabs([f"{HABITS[h]['icon']} {h}" for h in HABITS])
    for tab, h in zip(tabs, HABITS):
        with tab:
            a, b = st.columns([1.4, 1])
            with a:
                days = st.select_slider("Window (days)", [7, 14, 30], value=14, key=f"w_{h}")
                show(charts.trend_chart(records, h, end_date, days))
            with b:
                st.write("")
                st.write("")
                show(charts.distribution_chart(records, h))

elif page == "📦 Import & Export":
    hero("Import & Export", "Bring in legacy CSV files with row-by-row validation, or export reports for review.")
    t_exp, t_imp, t_data = st.tabs(["📤 Export reports", "📥 Bulk import", "🧰 Data tools"])

    with t_exp:
        md = markdown_report(summary, warnings_)
        txt = text_report(summary, warnings_)
        csv_text = records_csv(records)
        c1, c2, c3, c4 = st.columns(4)
        c1.download_button("⬇ Markdown summary", md, "habit_report.md", "text/markdown")
        c2.download_button("⬇ Text audit log", txt, "habit_audit_log.txt", "text/plain")
        c3.download_button("⬇ CSV records", csv_text, "habit_records.csv", "text/csv")
        fig = charts.report_figure(summary, records, end_date)
        c4.download_button("⬇ Chart (PNG)", fig_png(fig), "habit_charts.png", "image/png")
        plt.close(fig)
        with st.expander("Preview Markdown report", expanded=True):
            st.markdown(md)

    with t_imp:
        up = st.file_uploader("Choose a CSV (columns: date, habit, value, notes)", type=["csv"])
        replace = st.checkbox("Overwrite existing entries instead of skipping duplicates")
        if up is not None:
            valid, log, stats = parse_csv_import(up.getvalue(), [] if replace else records)
            m = st.columns(4)
            m[0].metric("Rows read", stats["total"])
            m[1].metric("Valid", stats["valid"])
            m[2].metric("Errors", stats["errors"])
            m[3].metric("Duplicates", stats["duplicates"])
            if log:
                st.dataframe(pd.DataFrame(log).rename(columns=str.title), hide_index=True)
                st.download_button("⬇ Download error log", import_log_csv(log), "import_log.csv", "text/csv")
            if valid and st.button(f"Import {len(valid)} valid row(s)", type="primary"):
                n = store.import_rows(valid, overwrite=replace)
                st.success(f"Imported {n} record(s).")
                st.rerun()
        else:
            st.caption("Tip: try `data/legacy_import_with_errors.csv` from the project folder to see the error log.")

    with t_data:
        st.markdown("**Demo data** – 40 realistic entries including boundary values and anomalies.")
        c1, c2 = st.columns(2)
        if c1.button("Load sample dataset"):
            try:
                sample = json.loads(SAMPLE_JSON.read_text(encoding="utf-8"))["records"]
                shifted = shift_records_to_end(sample, today() - timedelta(days=1))
                n = store.import_rows(shifted, overwrite=True)
                st.success(f"Loaded {n} sample records (dates shifted to end yesterday).")
                st.rerun()
            except (OSError, ValueError, KeyError):
                st.error("Sample file is missing or unreadable.")
        with c2:
            sure = st.checkbox("I understand this deletes all my records")
            if st.button("Delete all data", disabled=not sure):
                store.clear()
                st.rerun()
