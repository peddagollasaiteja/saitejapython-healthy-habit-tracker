"""Generate the 40-entry sample dataset (CSV + JSON) and a messy legacy CSV for import demos."""
import csv
import json
import random
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
DATA.mkdir(exist_ok=True)

random.seed(33)
END = date(2026, 11, 25)
days = [END - timedelta(days=i) for i in range(13, -1, -1)]  # 14 days -> 42 slots
rows = []
reading_notes = ["Finished a chapter", "Commute read", "Before bed", "Study session", "Audiobook"]
ex_notes = ["Morning jog", "Gym – legs", "Yoga", "Cycling", "Evening walk"]
hy_notes = ["Used the water bottle", "Tracked with bottle", "Forgot lunch", "Hot day", ""]

for i, d in enumerate(days):
    rows.append((d, "Reading", random.choice([15, 20, 25, 30, 35, 40, 45, 60]), random.choice(reading_notes)))
    rows.append((d, "Exercise", random.choice([0, 20, 25, 30, 40, 45, 50, 60]), random.choice(ex_notes)))
    rows.append((d, "Hydration", random.choice([1200, 1500, 1750, 2000, 2250, 2500, 2750]), random.choice(hy_notes)))

# Edge / boundary cases (overwrite specific slots) ----------------------------
def setv(day_idx, habit, value, note):
    for k, r in enumerate(rows):
        if r[0] == days[day_idx] and r[1] == habit:
            rows[k] = (r[0], habit, value, note)

setv(0, "Exercise", 0, "Rest day (boundary: zero)")
setv(3, "Reading", 600, "Marathon reading (boundary: max)")
setv(5, "Hydration", 0, "Forgot to log water (boundary: zero)")
setv(7, "Hydration", 5600, "Suspiciously high – triggers anomaly warning")
setv(9, "Exercise", 240, "Long hike (anomaly > 180)")
setv(11, "Reading", 5, "Very short session (low edge)")
setv(13, "Exercise", 30, "Exactly on goal")

# Drop 2 slots so the dataset has exactly 40 entries
for drop in ((days[2], "Reading"), (days[10], "Hydration")):
    rows = [r for r in rows if (r[0], r[1]) != drop]

assert len(rows) == 40, len(rows)
rows.sort(key=lambda r: (r[0], r[1]))

with open(DATA / "sample_habits.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["date", "habit", "value", "notes"])
    for d, h, v, n in rows:
        w.writerow([d.isoformat(), h, v, n])

records = [
    {"id": f"s{idx:03d}", "date": d.isoformat(), "habit": h, "value": v, "notes": n}
    for idx, (d, h, v, n) in enumerate(rows, 1)
]
(DATA / "sample_habits.json").write_text(json.dumps({"version": 1, "records": records}, indent=2), encoding="utf-8")

# Messy legacy file for the bulk-import error-log demo -----------------------
legacy = """date,habit,value,notes
2026-11-20,Reading,45,Valid row
2026-11-20,Yoga,30,Unknown habit
2026-11-21,Exercise,abc,Non-numeric value
2026-11-21,Hydration,12000,Out of range
21/11/2026,Reading,30,Wrong date format
2099-01-01,Reading,30,Future date
2026-11-22,Exercise,,Blank value
2026-11-22,Reading,35,Valid row
2026-11-22,Reading,35,Duplicate of previous row
2026-11-23,Hydration,2100,=HYPERLINK("evil") formula in notes
"""
(DATA / "legacy_import_with_errors.csv").write_text(legacy, encoding="utf-8")
print("Wrote", len(records), "records")
